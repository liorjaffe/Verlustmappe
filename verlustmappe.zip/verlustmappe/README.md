# Verlustmappe: an energy loss map of a PV → hydrogen → fuel cell island system

This repository computes **where the energy goes** in the Fotovoltaica/UFSC green-hydrogen
island plant, and **how sure we are about each number**. It is written so that one person
can read it top to bottom, understand every formula, and defend every result.

If you read only one thing, read Part 1. If you need to defend a number, go to
`docs/01_methods_handbook.md` and find its card.

---

## Part 1 · The idea in one page

### The question
Solar electricity is turned into hydrogen (electrolyser), the hydrogen is dried, compressed
and stored, and later turned back into electricity (fuel cell). Every step loses energy.
The **loss map** is the ordered list of those losses, in kWh, for one charge/discharge cycle.
The **round-trip efficiency (RTE)** is what is left at the end divided by what went in.

### The problem that shapes everything
**There is no hydrogen flow meter.** Nothing in this plant measures how much hydrogen
actually flows. Electricity is measured well (telemetry from every device). Hydrogen is not.
Yet every loss between the electrolyser and the fuel cell is a hydrogen loss.

### The solution: estimate hydrogen several independent ways and compare
| Route | Uses | Independent of electricity? | Status today |
|---|---|---|---|
| 1 Faraday | stack current · time · number of cells | no | needs stack-current export (EL) / unavailable (FC) |
| 2 Tank pressure | pressure change · tank volume · real-gas law | **yes** | needs tank volume + manual gauge readings |
| 3 Telemetry | device-reported H₂ flow | no (same source as 1) | available, correlated with Route 1 |
| 4 Water | water consumed / 8.94 | **yes** | needs a scale or water meter |
| N Nameplate | energy × datasheet specific consumption | n/a | always available, **constant efficiency by construction** |

When independent routes agree, the hydrogen number is trustworthy. When they disagree, the
**disagreement is the uncertainty** we report. This replaces the missing meter with an honest
error bar. It is the scientific contribution of the project.

### The three rules that keep it honest
1. **Every number has a status.** DATASHEET, MEASURED, DERIVED, GUESS or BACKLOG. No number
   enters a calculation without one (`src/verlustmappe/registry.py`).
2. **Every formula has a card.** What, formula, source, assumptions, error-if-wrong, code, test
   (`docs/01_methods_handbook.md`).
3. **Every result says how it was obtained.** Each device returns `efficiency_is_measured`;
   each loss-map bar carries MEASURED / ENVELOPE / GUESS / NAMEPLATE. A figure may never show a
   nameplate constant as if it were a measurement.

---

## Part 2 · What you are looking at (folder by folder)

```
verlustmappe/
├── README.md                      you are here
├── docs/
│   ├── 01_methods_handbook.md     one card per formula (the defence document)
│   ├── 02_uncertainty_register.md every assumption, weakest first (generated from registry)
│   ├── 03_data_dictionary.md      every column name, unit, raw source, caveat
│   ├── 04_validation_log.md       which test proves what; bugs the tests caught
│   ├── 05_roadmap_original.md     the feature roadmap of the interactive tool (history)
│   ├── 06_roadmap_decisions.md    what went into the pipeline vs. stayed interactive
│   └── 07_critical_review_history.md  earlier audits (history)
├── src/verlustmappe/              the Python package (all calculation lives here)
│   ├── constants.py               physical constants with sources   ← facts
│   ├── registry.py                device parameters with status     ← assumptions
│   ├── conversions.py             the textbook formulas (Faraday, gas law, work, integral)
│   ├── hydrogen/                  the five hydrogen routes + closure  ← scientific core
│   ├── devices/                   one file per device: EL, dryer, booster, tank, FC, PV
│   ├── balance/                   modes, steady segments, events, RTE, the loss map
│   ├── analysis/                  curves, dynamics, degradation, comparison
│   ├── uncertainty/               RSS propagation and Monte-Carlo band
│   ├── loaders/                   raw Grafana/SMA exports → pipeline columns
│   ├── reporting/                 tables and figures into results/
│   └── live.py                    rolling-window wrapper for a live plotter
├── tools/
│   ├── regatron/                  tested Regatron G5.BT blueprint + bridge + analyzer (input & control)
│   ├── fuelcell_analyzer.html     interactive CSV inspection
│   └── server.py, simulate_data.py  live feed
├── tests/                         run_all.py; each test states its ground truth
├── data/raw/                      untouched exports (evidence; never edited)
├── data/processed/                merged, unit-labelled datasets
└── results/plots, results/tables  everything generated; safe to delete and regenerate
```

**Reading order for a newcomer:** this README → `constants.py` → `registry.py` →
`conversions.py` → `hydrogen/__init__.py` and its five files → `devices/` → `balance/chain.py`
→ `docs/01_methods_handbook.md`. About two hours.

---

## Part 3 · The chain, device by device

```
 PV array ──DC──▶ SMA inverter ──AC──▶ Electrolyser EL 2.1 ──H₂ 35 bar──▶ Dryer DRY 2.1
   [measured]      [measured]           [measured E_in]                   [envelope E, GUESS vent]
                                                                                │
                                                        ┌───────────────────────┘
                                                        ▼
                Fuel cells 2×IE-LIFT 802 ◀──H₂ 0.6 bar── Storage tank ◀──H₂ 200 bar── Air-driven booster
                [measured E_out; H₂ by route]  [Route 2 anchor]              [GUESS efficiency; meter the Kaeser]
                        │
                        ▼ 48 V DC bus (battery in parallel)          ┌──────────────────────────┐
                 AC inverter ──▶ island load                         │ Regatron G5.BT as load   │
                 [assumed 0.96 until metered]                        │ 20 Hz fast log = MEASURED│
                                                                     │ load-branch current      │
                                                                     └──────────────────────────┘
```

For each device the code answers the same three questions, in a dict with the same keys:
energy in, energy/hydrogen out, what was lost and with what status. The loss map
(`balance/chain.py`) simply puts the dicts in a row.

**Where the energy goes in the synthetic demo** (`tests/test_03_full_chain.py`, 14.4 kWh in):

| Stage | kWh | Status | Why that status |
|---|---|---|---|
| EL conversion | 5.5 | MEASURED* | Route 1 from stack current (*synthetic) |
| Dryer electrical | 1.2 | ENVELOPE | 200 W datasheet upper value |
| Dryer vent (H₂) | 0.36 | GUESS | 4% of throughput, unmeasured |
| Compression | 1.5 | GUESS | ideal work / 10% assumed efficiency |
| FC conversion | 6.8 | MEASURED* | reverse Faraday (*synthetic) |
| FC control | 0.30 | ENVELOPE | 150 W nameplate max |
| Inverter | 0.19 | ASSUMED | 96% |
| **Delivered** | **3.8** | | **RTE ≈ 26%**, Monte-Carlo 5–95%: 22–28% |

Read the status column first, the kWh column second. That is the discipline.

---

## Part 4 · What the real data says so far (and what it cannot say)

**Fuel cell, 22 Sept 2026, 3 h log.** 14 steady segments at ≈1.38 kW, 8 purge candidates
from anode-pressure drops, 2.93 kWh delivered, terminal voltage rising 47.8→50.8 V at
constant current (warm-up). What it **cannot** say: the fuel-cell efficiency. The telemetry
current is the DC/DC output, not the stack current, so only Route N applies, and Route N is
the constant 42.9% by construction. The pipeline therefore labels this result `nameplate_fc`
and refuses `efficiency_is_measured`.

**Regatron load branch (controlled input, to come).** The tested
`tools/regatron/` bridge + blueprint drives the G5.BT as a programmable load
(CC/CV/CP, polarization sweeps with round-trip hysteresis, load steps) and
logs the bus at 20 Hz on a real clock. In the pipeline this is the measured
`load_current_A` that turns the battery branch from a guess into a residual
over three measured branches, and the polarization sweep is a swept (not
segment-derived) V-I characteristic. Loader: `loaders/regatron.py`.

**PV, 9–30 Sept 2026, 22 days.** 4.1 MWh AC; inverter efficiency measured from DC and AC:
0.62 below 2 kW, 0.92 at 2–10 kW, 0.97 at 10–30 kW, 0.98 above 30 kW. This bar of the loss
map is genuinely measured.

**Electrolyser.** Only daily aggregates of H₂ production and pressures so far. No electrical
or stack data. Route 1 waits for the `stack_amperage` export (firmware 1.12 collects it).

---

## Part 5 · How to run it

```bash
python3 tests/run_all.py                       # all tests, each prints its ground truth
python3 src/verlustmappe/reporting/report_cli.py fc data/processed/fc_retro/fc_merged.csv
python3 src/verlustmappe/reporting/report_cli.py pv data/processed/pv_retro/pv_merged.csv
```
Outputs land in `results/tables/*.csv` and `results/plots/`. Open any CSV in
`tools/fuelcell_analyzer.html` (double-click the file, drag the CSV in) to inspect
interactively. The HTML tool displays; it never produces a paper number.

---

## Part 6 · Defending the project: the questions you will be asked

**"You have no hydrogen meter. How can you claim any hydrogen number?"**
We do not measure hydrogen; we estimate it by routes that share no inputs (Faraday from
current, real-gas law from tank pressure, stoichiometry from water) and report their
disagreement as the uncertainty. This is standard closure practice when a direct measurement
is missing (see handbook card G). The comparison set in the literature uses a single derived
route with no stated uncertainty; ours is more conservative.

**"Why is the fuel-cell efficiency exactly 42.9%?"**
Because with today's telemetry only the nameplate route exists, and that route is the
datasheet constant. The code says so (`efficiency_is_measured = False`). Getting a
load-dependent efficiency requires the stack current or an H₂ meter. We state this as a
limitation, not a result.

**"Why do you trust Faraday's law with an assumed cell count?"**
We do not trust it blindly: cell count and Faradaic efficiency are GUESS entries with stated
uncertainties, they enter the Monte-Carlo band, and Route 2 (tank) is designed to check
Route 1 independently. When the two disagree, the residual is the gas lost between stack and
tank, itself a loss-map entry.

**"Is 200 bar hydrogen an ideal gas?"**
No. Z = 1.13 at 200 bar, 20 °C (NIST). Ignoring it overstates stored mass by 13%. The code
uses the tabulated Z with ±0.5% (card C).

**"Why two RTE numbers?"**
Storage-chain RTE (AC in → AC out) is comparable with the literature. Island RTE (PV-AC in →
AC out) tells the story of this plant. Same pipeline, two boundaries (card K).

**"What is the weakest number in the whole map?"**
Today: the tank volume (a placeholder) and the compression energy (±50%). Both are fixed by
reading nameplates and installing one energy meter, not by more modelling. See
`docs/02_uncertainty_register.md`, section "five weakest numbers".

**"What did you do that the Veritas paper did not?"**
Explicit hydrogen-side uncertainty via independent routes; event-resolved (startup, standby,
POC, purge) energy accounting instead of two steady-state points; provenance status on every
number; a Monte-Carlo band over the assumptions.

---

## Part 7 · Conventions (memorise these)

- **NL** = litre at 0 °C, 1 atm. 1 NL H₂ = 89.9 mg = 2.997 Wh (LHV). 1 kg = 11.1 Nm³ = 33.32 kWh.
- **LHV everywhere** unless a label says HHV. HHV/LHV = 1.183.
- **barg** in the data, absolute in the formulas (+1.01325).
- **kWh** for energy in every returned dict; joules only inside `conversions.py`.
- Efficiency **η = useful out / in** on the same energy basis; RTE = discharged / charged.
- **Uncertainties are relative** (fractions) unless the unit says otherwise; combined by
  root-sum-square when independent.
