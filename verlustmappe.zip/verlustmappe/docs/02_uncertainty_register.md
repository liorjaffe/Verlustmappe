# Uncertainty register

All assumptions in the model, sorted from weakest to strongest. Generated from
`src/verlustmappe/registry.py` by `reporting/make_register.py`; edit the registry, not this file.

Status: BACKLOG = placeholder, MUST be replaced. GUESS = assumption bounded only by literature/physics.
DERIVED = computed from other entries. DATASHEET = manufacturer claim. MEASURED = measured by us.

| Status | Key | Value | Unit | Rel. unc. | Source | What it drives |
|---|---|---|---|---|---|---|
| BACKLOG | `bat.capacity_Ah` | 100 | Ah | 0.05 | PLACEHOLDER - enter the real battery capacity | SoC bookkeeping route for the battery branch |
| BACKLOG | `stor.volume_L` | 100 | L | 0.01 | PLACEHOLDER - enter the real geometric tank volume | Route 2 (tank pV) mass scales linearly with this |
| BACKLOG | `pv.p_dc_stc_W` | 0 | W | 0.0 | PLACEHOLDER - array STC power from module datasheets | capture-ratio bar (optional) |
| GUESS | `dry.vent_fraction` | 0.04 | fraction of throughput | 0.5 | ASSUMPTION: TSA/PSA regeneration vents the cartridge hold-up; unmeasured | gas loss bar in the loss map; bound it via long-run tank-pV vs Faraday residual |
| GUESS | `comp.overall_efficiency` | 0.1 | - | 0.5 | ASSUMPTION: ideal isothermal H2 work / electrical energy of the compressed-air supply (Kaeser). Air-driven boosters are notoriously inefficient; 5-15% typical. | compression loss bar; MUST be replaced by Kaeser energy measurement |
| GUESS | `stor.gauge_uncertainty_rel` | 0.02 | - | 0.5 | ASSUMPTION: analog gauge, read manually, class ~1.6 + parallax | Route 2 uncertainty; calibrate the gauge to shrink this |
| GUESS | `meas.power_rel_unc` | 0.02 | - | 0.5 | ASSUMPTION: device-reported power (Enapter/SMA telemetry), no independent power analyser yet | floor of every efficiency's uncertainty |
| GUESS | `el.n_cells` | 120 | - | 0.05 | ASSUMPTION consistent with 2400 W / (120 x 2.0 V) = 10 A; CONFIRM from Enapter (stack spec not public) | Faraday route scales linearly with this number |
| GUESS | `fc.n_cells` | 120 | - | 0.05 | ASSUMPTION (IE-LIFT stack spec not public); CONFIRM | reverse-Faraday route |
| GUESS | `el.faradaic_efficiency` | 0.98 | - | 0.02 | ASSUMPTION: literature AEM/PEM current efficiency 96-99% (Yodwong et al., Energies 2020, 13, 4792) | Faraday route H2 mass; blind to shunt current and crossover |
| GUESS | `fc.faradaic_efficiency` | 1.0 | - | 0.02 | ASSUMPTION: all stack current from H2 oxidation (no crossover) | reverse-Faraday route |
| DERIVED | `el.startup_duration_s` | 990 | s | 0.15 | UFSC PV-electrolysis study: EL2.1 ramp to nominal after ~990 s | operating-mode partition: startup window length |
| DERIVED | `stor.p_min_barg` | 20 | barg | 0.0 | = booster minimum suction pressure | depth of discharge |
| DERIVED | `fc.poc_max_duration_s` | 12 | s | 0.0 | FCM802_Test research plan / user manual | POC event window |
| DATASHEET | `el.water_consumption_mLh` | 400 | mL/h | 0.1 | Enapter EL 2.1 datasheet | Route 4 (water balance) expectation |
| DATASHEET | `el.power_standby_W` | 15 | W | 0.05 | Enapter EL 2.1 datasheet | standby loss bar in the loss map |
| DATASHEET | `dry.power_standby_W` | 10 | W | 0.05 | DRY 2.1 datasheet | standby loss |
| DATASHEET | `fc.h2_consumption_g_per_kWh` | 70 | g/kWh | 0.05 | IE-LIFT 802 nameplate: '<70 g per kWh' at 25 C, beginning of life | nameplate H2 route. NOTE: it is an UPPER BOUND on consumption, hence a LOWER BOUND on efficiency (42.9% LHV), and makes FC efficiency a constant by construction. Load dependence needs the stack-current route. |
| DATASHEET | `fc.control_input_W_max` | 150 | W | 0.05 | IE-LIFT 802 nameplate 'Rated Input 150 W max' | auxiliary/control energy on discharge; nameplate MAX, so an upper envelope |
| DATASHEET | `el.spec_energy_kWh_per_Nm3` | 4.8 | kWh/Nm3 | 0.03 | Enapter EL 2.1 datasheet, beginning of life | FALLBACK H2 estimate when no stack current is logged; WARNING: makes EL efficiency a constant 62.4% by construction |
| DATASHEET | `dry.spec_energy_kWh_Nm3` | 0.045 | kWh/Nm3 | 0.03 | DRY 2.1 datasheet | alternative dryer energy estimate: flow-proportional |
| DATASHEET | `el.production_rate_NLh` | 500 | NL/h | 0.02 | Enapter EL 2.1 datasheet (ELE21-DTS-COM02) | nominal H2 output; cross-check for Faraday route |
| DATASHEET | `el.power_operative_W` | 2400 | W | 0.02 | Enapter EL 2.1 datasheet | nominal AC input; steady-state expectation |
| DATASHEET | `dry.power_operative_W` | 200 | W | 0.02 | DRY 2.1 datasheet | dryer electrical loss bar; NOTE datasheet also states 0.045 kWh/Nm3 at 2.5 Nm3/h = 112 W average, so 200 W is an UPPER envelope |
| DATASHEET | `bat.nominal_V` | 48 | V | 0.01 | system DC bus | SoC energy conversion |
| DATASHEET | `el.h2_purity` | 0.999 | mol fraction | 0.0005 | Enapter EL 2.1 datasheet (35 bar) | mass bookkeeping: impurities are not H2 |
| DATASHEET | `el.output_pressure_barg` | 35 | barg | 0.0 | Enapter EL 2.1 datasheet | compressor inlet pressure |
| DATASHEET | `dry.rate_Nm3h` | 2.5 | Nm3/h | 0.0 | DRY 2.1 datasheet (35 bar version) | capacity check |
| DATASHEET | `dry.max_h2_content_NL` | 47 | NL | 0.0 | DRY 2.1 datasheet (safety: max H2 in device) | upper bound of H2 lost per regeneration blow-down |
| DATASHEET | `comp.pressure_ratio` | 60 | - | 0.0 | Maximator DLE 30-2 TDS | stall pressure check |
| DATASHEET | `comp.stroke_volume_cm3` | 120 | cm3/double stroke | 0.0 | Maximator DLE 30-2 TDS | flow capacity check |
| DATASHEET | `comp.max_cycles_per_min` | 100 | 1/min | 0.0 | Maximator DLE 30-2 TDS | flow capacity check |
| DATASHEET | `comp.min_suction_bar` | 20 | bar | 0.0 | Maximator DLE 30-2 TDS | storage lower pressure limit |
| DATASHEET | `stor.p_max_barg` | 300 | barg | 0.0 | UFSC lab description (tanks up to 300 bar) | range check |
| DATASHEET | `fc.rated_power_W` | 2500 | W at 48 V | 0.0 | IE-LIFT 802 nameplate | load-bin normalisation |
| DATASHEET | `fc.has_internal_dcdc` | True | bool | 0.0 | IE-LIFT 802 telemetry exposes 'DC/DC Voltage Set Point' and 'DC/DC Current Limit'; output 20-56 V follows the bus | Terminal V/I is NOT stack V/I. Terminal V-I curve is a converter characteristic, not a polarisation curve. |

## The five weakest numbers and how to fix each

1. `stor.volume_L` (BACKLOG). Read the tank nameplates, sum geometric volumes. Route 2 is meaningless until then.
2. `comp.overall_efficiency` (GUESS +-50%). Energy meter on the Kaeser air compressor during booster runs.
3. `dry.vent_fraction` (GUESS +-50%). Bound with a long charge window: Faraday - tank-pV - known leaks.
4. `stor.gauge_uncertainty_rel` (GUESS). Calibrate the gauge once; plan pressure swings > 100 bar.
5. `el.n_cells` / `fc.n_cells` (GUESS). Ask the manufacturers; Faraday routes scale linearly with them.

## Constants by construction (never present as measurements)

- EL efficiency via the nameplate route = 62.4% LHV for any data.
- FC efficiency via the nameplate route = 42.9% LHV for any data (a lower bound: nameplate says '<70 g/kWh').
