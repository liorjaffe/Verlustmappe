"""Four independent-ish ways to estimate the hydrogen mass in a time window.

No hydrogen flow meter exists in this plant. Therefore hydrogen mass is never
"measured"; it is ESTIMATED by several routes and the routes are compared
(closure.py). The disagreement between routes IS the reported hydrogen
uncertainty. This is the scientific core of the project.

  Route 1  faraday.py    stack current -> H2 mass       (electrical, needs stack current)
  Route 2  tank_pv.py    tank pressure change -> mass   (thermodynamic, INDEPENDENT anchor)
  Route 3  telemetry.py  device-reported H2 flow        (NOT independent of Route 1)
  Route 4  water.py      water consumed -> H2 mass      (stoichiometric, cheap cross-check)
  Route N  nameplate.py  datasheet specific consumption (a BOUND, constant by construction)
"""
from .faraday import h2_from_stack_current
from .tank_pv import h2_from_tank_pressure
from .telemetry import h2_from_telemetry
from .water import h2_from_water
from .nameplate import h2_from_energy_nameplate
from .closure import compare_routes
