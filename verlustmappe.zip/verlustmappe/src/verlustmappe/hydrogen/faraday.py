"""Route 1: hydrogen from stack current (Faraday's law).

    n_H2 = eta_F * n_cells * (integral I_stack dt) / (2 F)

Inputs that are assumptions: n_cells (GUESS), eta_F (GUESS).
What this route CANNOT see: shunt currents, gas crossover, leaks, purge losses.
It therefore estimates hydrogen PRODUCED at the stack (electrolyser) or
CONSUMED at the stack (fuel cell), not hydrogen delivered to / taken from storage.

Precondition: the current must be the STACK current. The IE-LIFT 802 fuel cell
has an internal DC/DC converter; its telemetry 'Amperage' is the OUTPUT terminal
current and must NOT be used here.
"""
import numpy as np
from ..conversions import mol_from_charge, mol_to_kg, mol_to_NL, kg_to_kWh_LHV
from .. import registry as R

def h2_from_stack_current(I_stack_paths, dt_s, n_cells, faradaic_eff):
    """I_stack_paths: list of 1-D arrays, one per parallel stack (e.g. two FC
    modules). dt_s: array of sample intervals [s] or scalar."""
    paths = I_stack_paths if isinstance(I_stack_paths, (list, tuple)) else [I_stack_paths]
    mol = sum(mol_from_charge(np.asarray(p, float), np.broadcast_to(dt_s, np.shape(p)), n_cells)
              for p in paths) * faradaic_eff
    kg = mol_to_kg(mol)
    # uncertainty: root-sum-square of the relative uncertainties of the inputs
    u = float(np.sqrt(R.entry("el.n_cells")["uncertainty"]**2 +
                      R.entry("el.faradaic_efficiency")["uncertainty"]**2 +
                      R.get("meas.power_rel_unc")**2))
    return dict(route="faraday", mol=mol, kg=kg, NL=mol_to_NL(mol), kWh_LHV=kg_to_kWh_LHV(kg),
                uncertainty_rel=u, independent_of=["tank_pv", "water"],
                blind_to=["shunt current", "crossover", "leaks", "purge/vent losses"])
