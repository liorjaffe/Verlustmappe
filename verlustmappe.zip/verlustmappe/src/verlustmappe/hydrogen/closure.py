"""Compare hydrogen routes. The spread between INDEPENDENT routes is the
honest hydrogen-side uncertainty of the whole loss map.

Method: inverse-variance weighted mean (standard, e.g. Taylor, An Introduction
to Error Analysis, ch. 7) of the routes declared independent of each other;
report each route's deviation from that mean and the maximum spread.
Correlated routes (telemetry vs faraday) are reported but excluded from the mean.
"""
import numpy as np

def compare_routes(routes, exclude=("telemetry", "nameplate_el", "nameplate_fc")):
    used = [r for r in routes if r["route"] not in exclude and np.isfinite(r["kg"])]
    if not used:
        return dict(mean_kg=None, note="no independent routes available")
    vals = np.array([r["kg"] for r in used])
    sig = np.array([max(r["uncertainty_rel"], 1e-3) * abs(r["kg"]) for r in used])
    w = 1.0 / sig**2
    mean = float(np.sum(w * vals) / np.sum(w))
    u_mean = float(1.0 / np.sqrt(np.sum(w)) / abs(mean)) if mean else None
    devs = {r["route"]: float((r["kg"] - mean) / mean) for r in routes if mean}
    spread = float((vals.max() - vals.min()) / abs(mean)) if mean else None
    return dict(mean_kg=mean, weighted_uncertainty_rel=u_mean, deviations=devs,
                max_spread_independent=spread, n_independent=len(used),
                reported_uncertainty_rel=max(u_mean or 0, spread or 0),
                note="reported uncertainty = max(statistical, spread); spread dominates when routes disagree")
