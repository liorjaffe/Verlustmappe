"""Compressibility factor Z of hydrogen.

Why it matters: at 200 bar hydrogen holds ~12% LESS mass than the ideal gas
law predicts. Ignoring Z biases Route 2 by that amount.

Source of the table: NIST Chemistry WebBook / REFPROP, thermophysical
properties of normal hydrogen (equation of state of Leachman, Jacobsen, Penoncello
& Lemmon, J. Phys. Chem. Ref. Data 38, 721 (2009)). Values at 20 C (293.15 K),
rounded to 3 decimals. Well-known check points: Z(350 bar, 15 C) = 1.234;
density(200 bar, 20 C) = 14.6 kg/m3 -> Z = 1.13.

Temperature correction: (Z - 1) scales approximately with 1/T in the ambient
range (second-virial behaviour), so Z(p,T) = 1 + (Z(p,20C) - 1) * 293.15 / T.
Stated uncertainty of this table+correction: +-0.5% for 0-300 bar, 0-50 C.
"""
import numpy as np

_P_BAR = np.array([1, 25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 350])
_Z_20C = np.array([1.0006, 1.016, 1.032, 1.048, 1.065, 1.081, 1.098, 1.115,
                   1.132, 1.149, 1.166, 1.183, 1.200, 1.234])

def z_h2(p_abs_bar, T_C=20.0):
    """Compressibility factor of H2 at absolute pressure p [bar] and T [C]."""
    z20 = float(np.interp(p_abs_bar, _P_BAR, _Z_20C))
    return 1.0 + (z20 - 1.0) * 293.15 / (T_C + 273.15)

Z_TABLE_UNCERTAINTY_REL = 0.005
