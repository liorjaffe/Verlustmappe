"""Route 2: hydrogen from the storage tank pressure change.

    delta n = V/(R) * [ p2/(Z(p2) T2) - p1/(Z(p1) T1) ]

This is the ONLY route that does not depend on electrochemistry. It sees ALL
gas that reached the tank, so (Faraday minus tank_pv) over a charge window is
the total gas lost between stack and tank (purge, vent, leak).

Inputs that are assumptions: tank volume (BACKLOG!), Z table (0.5%), gauge
reading (GUESS 2%), gas temperature (use ambient unless measured).
"""
import numpy as np
from ..conversions import mol_from_pVT, mol_to_kg, mol_to_NL, kg_to_kWh_LHV
from .. import constants as C
from .. import registry as R
from .realgas import z_h2, Z_TABLE_UNCERTAINTY_REL

def h2_from_tank_pressure(p_start_barg, p_end_barg, T_start_C=20.0, T_end_C=None):
    if T_end_C is None: T_end_C = T_start_C
    V = R.get("stor.volume_L") / 1000.0
    p1, p2 = p_start_barg + C.P_ATM_BAR, p_end_barg + C.P_ATM_BAR
    n1 = mol_from_pVT(p1, V, T_start_C + 273.15, z_h2(p1, T_start_C))
    n2 = mol_from_pVT(p2, V, T_end_C + 273.15, z_h2(p2, T_end_C))
    dmol = n2 - n1
    kg = mol_to_kg(dmol)
    # uncertainty: gauge reading enters twice (two readings), volume once, Z once,
    # temperature 1 K on 293 K ~0.3% each reading
    g = R.get("stor.gauge_uncertainty_rel")
    # a pressure DIFFERENCE amplifies relative gauge error by p/(p2-p1)
    amp = max(p1, p2) / max(abs(p2 - p1), 1e-9)
    u = float(np.sqrt((g * amp * np.sqrt(2))**2 + R.entry("stor.volume_L")["uncertainty"]**2 +
                      Z_TABLE_UNCERTAINTY_REL**2 + (2 * 1.0 / 293.15)**2))
    return dict(route="tank_pv", mol=dmol, kg=kg, NL=mol_to_NL(dmol), kWh_LHV=kg_to_kWh_LHV(kg),
                uncertainty_rel=u, independent_of=["faraday", "telemetry", "water", "nameplate"],
                blind_to=["nothing upstream; but only sees net change in the tank"],
                note="small pressure swings give large relative errors: amp=%.1f" % amp)
