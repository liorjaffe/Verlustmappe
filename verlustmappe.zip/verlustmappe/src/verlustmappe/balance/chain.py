"""The loss map: run one charge/discharge cycle through every device and list
where the energy went. Returns an ordered list of bars (kWh) plus flags saying
which bars are measured, which are envelopes, and which are guesses."""
from ..devices import ElectrolyzerUnit, Dryer, AirDrivenBooster, FuelCellSystem
from ..hydrogen import h2_from_tank_pressure, compare_routes
from .. import registry as R
from .rte import storage_chain_rte, island_rte

def loss_map(df_charge, df_discharge, tank_p_start_barg=None, tank_p_end_barg=None,
             p_in_barg=35.0, p_out_barg=200.0, eta_inverter=0.96, E_pv_ac_kWh=None,
             air_compressor_kWh=None, dryer_kWh=None):
    el = ElectrolyzerUnit().account(df_charge)
    hours = (df_charge.index[-1] - df_charge.index[0]).total_seconds() / 3600.0
    dry = Dryer().account(hours, el["h2"]["NL"], measured_kWh=dryer_kWh)
    NL_to_tank = el["h2"]["NL"] - dry["gas_loss_NL"]
    comp = AirDrivenBooster().account(NL_to_tank, p_in_barg, p_out_barg, air_compressor_kWh=air_compressor_kWh)
    fc = FuelCellSystem().account(df_discharge)

    routes = [el["h2"] | {"kg": el["h2"]["kg"] * (1 - R.get("dry.vent_fraction"))}]
    routes[0]["route"] = el["h2"]["route"] + "_minus_vent"
    if tank_p_start_barg is not None and tank_p_end_barg is not None:
        routes.append(h2_from_tank_pressure(tank_p_start_barg, tank_p_end_barg))
    closure = compare_routes(routes)

    rte = storage_chain_rte(el["energy_in_kWh"], dry["energy_kWh"], comp["energy_kWh"],
                            fc["energy_out_kWh"], fc["control_energy_kWh_envelope"], eta_inverter,
                            E_standby_kWh=0.0)
    bars = [
        dict(stage="EL conversion", kWh=el["energy_in_kWh"] - el["h2"]["kWh_LHV"], status="MEASURED" if el["efficiency_is_measured"] else "NAMEPLATE"),
        dict(stage="Dryer electrical", kWh=dry["energy_kWh"], status="MEASURED" if dry["energy_is_measured"] else "ENVELOPE"),
        dict(stage="Dryer vent (H2)", kWh=dry["gas_loss_kWh_LHV"], status="GUESS"),
        dict(stage="Compression", kWh=comp["energy_kWh"], status="MEASURED" if comp["energy_is_measured"] else "GUESS"),
        dict(stage="FC conversion", kWh=fc["h2"]["kWh_LHV"] - fc["energy_out_kWh"], status="MEASURED" if fc["efficiency_is_measured"] else "NAMEPLATE"),
        dict(stage="FC control", kWh=fc["control_energy_kWh_envelope"], status="ENVELOPE"),
        dict(stage="Inverter", kWh=(fc["energy_out_kWh"] - fc["control_energy_kWh_envelope"]) * (1 - eta_inverter), status="MEASURED" if eta_inverter != 0.96 else "ASSUMED"),
    ]
    out = dict(devices=dict(EL=el, DRY=dry, CSU=comp, FC=fc), h2_closure=closure, rte=rte, bars=bars)
    if E_pv_ac_kWh is not None:
        out["island"] = island_rte(E_pv_ac_kWh, rte)
    return out
