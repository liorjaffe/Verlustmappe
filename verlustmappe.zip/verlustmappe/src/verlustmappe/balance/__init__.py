"""Energy bookkeeping across devices and operating modes.

  modes.py       label every sample: standby / startup / steady / event
  segments.py    find steady-state windows (for characteristic curves)
  events.py      robust event detection (median/MAD), purge/POC candidates
  rte.py         round-trip efficiency at two system boundaries
  chain.py       the loss map: put all devices in a row and account
"""
from .modes import partition_modes
from .segments import steady_segments
from .events import detect_events, purge_candidates
from .rte import storage_chain_rte, island_rte
from .chain import loss_map
