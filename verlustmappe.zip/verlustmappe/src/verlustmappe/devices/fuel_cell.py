"""Fuel cell system: 2 x IE-LIFT 802 on a 48 V bus with a battery.

Energy out: terminal power telemetry integrated (trapezoid).
H2 in:      reverse-Faraday if STACK current columns exist (they do not in the
            current telemetry: 'Amperage' is the DC/DC OUTPUT current), else
            nameplate 70 g/kWh, which is an upper bound and makes efficiency a
            constant 42.9% LHV.
Aux:        control input, nameplate MAX 150 W -> upper envelope.
Battery:    no sensor. Current residual I_bat = I_load - sum(I_fc,terminal)
            when a load current column exists; otherwise None.
"""
import numpy as np
from .. import registry as R
from ..conversions import energy_kWh_from_power
from ..hydrogen import h2_from_stack_current, h2_from_energy_nameplate
from ._common import t_seconds

class FuelCellSystem:
    def __init__(self, n_modules=2):
        self.n = n_modules

    def account(self, df):
        t = t_seconds(df.index)
        P = df["fc_power_W"].values.astype(float)
        e_out = energy_kWh_from_power(P, t)
        dt = np.gradient(t) if len(t) > 1 else np.array([1.0])
        stack_cols = [c for c in df.columns if c.endswith("_stack_current_A")]
        if stack_cols:
            h2 = h2_from_stack_current([df[c].fillna(0).values for c in stack_cols], dt,
                                       R.get("fc.n_cells"), R.get("fc.faradaic_efficiency"))
            h2["route"] = "reverse_faraday"; eff_is_measured = True
        else:
            h2 = h2_from_energy_nameplate(e_out, "fc"); eff_is_measured = False
        eta = e_out / h2["kWh_LHV"] if h2["kWh_LHV"] > 0 else None
        e_ctrl = R.get("fc.control_input_W_max") / 1000.0 * (t[-1] - t[0]) / 3600.0 if len(t) > 1 else 0.0
        I_bat = None
        term = [c for c in df.columns if c.endswith("_current_A") and "stack" not in c and c != "load_current_A"]
        if "load_current_A" in df.columns and term:
            I_bat = df["load_current_A"].fillna(0).values - sum(df[c].fillna(0).values for c in term)
        return dict(unit="FCU", energy_out_kWh=e_out, h2=h2, efficiency_LHV=eta,
                    efficiency_is_measured=eff_is_measured,
                    control_energy_kWh_envelope=e_ctrl, battery_current_residual_A=I_bat,
                    warning=None if eff_is_measured else
                    "FC efficiency is the nameplate constant (terminal current is not stack current)")
