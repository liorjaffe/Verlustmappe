"""Electrolyser unit (EL 2.1 incl. its AC/DC power supply).

Energy in:   AC power telemetry integrated over the window (trapezoid).
H2 out:      Route 1 if a STACK current column exists, else Route N (nameplate)
             with a loud 'constant-efficiency' flag.
Efficiency:  eta_LHV = E_H2,LHV / E_AC   (IEA definition for electrolysers)
Standby:     energy in samples where P <= 3 x standby power.
"""
import numpy as np
from .. import registry as R
from ..conversions import energy_kWh_from_power
from ..hydrogen import h2_from_stack_current, h2_from_energy_nameplate
from ._common import t_seconds

class ElectrolyzerUnit:
    def account(self, df):
        t = t_seconds(df.index)
        P = df["power_W"].values.astype(float)
        e_in = energy_kWh_from_power(P, t)
        dt = np.gradient(t) if len(t) > 1 else np.array([1.0])
        if "el_stack_current_A" in df.columns and df["el_stack_current_A"].notna().any():
            h2 = h2_from_stack_current([df["el_stack_current_A"].fillna(0).values], dt,
                                       R.get("el.n_cells"), R.get("el.faradaic_efficiency"))
            eff_is_measured = True
        else:
            h2 = h2_from_energy_nameplate(e_in, "el")
            eff_is_measured = False
        eta = h2["kWh_LHV"] / e_in if e_in > 0 else None
        stby = P <= 3 * R.get("el.power_standby_W")
        return dict(unit="ELU", energy_in_kWh=e_in, h2=h2, efficiency_LHV=eta,
                    efficiency_is_measured=eff_is_measured,
                    standby_kWh=energy_kWh_from_power(np.where(stby, P, 0.0), t),
                    warning=None if eff_is_measured else
                    "EL efficiency is the nameplate constant (no stack current in data)")
