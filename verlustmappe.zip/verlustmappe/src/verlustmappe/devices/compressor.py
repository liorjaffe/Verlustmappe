"""Air-driven gas booster (Maximator DLE 30-2).

The booster itself consumes no electricity; it consumes COMPRESSED AIR made by
an electric air compressor (Kaeser). The electrical loss of the compression
stage is therefore the air compressor's energy while the booster runs.

  W_ideal = n R T ln(p2/p1)          minimum work (isothermal)
  eta_overall = W_ideal / E_air_compressor
Until E_air_compressor is metered, E is estimated as W_ideal / eta_GUESS.
"""
from .. import registry as R
from .. import constants as C
from ..conversions import isothermal_work_kWh, NL_to_mol

class AirDrivenBooster:
    def account(self, throughput_NL, p_in_barg, p_out_barg, T_C=20.0, air_compressor_kWh=None):
        mol = NL_to_mol(throughput_NL)
        w_ideal = isothermal_work_kWh(mol, p_in_barg + C.P_ATM_BAR, p_out_barg + C.P_ATM_BAR, T_C + 273.15)
        if air_compressor_kWh is not None:
            return dict(unit="CSU", ideal_work_kWh=w_ideal, energy_kWh=air_compressor_kWh,
                        overall_efficiency=w_ideal / air_compressor_kWh if air_compressor_kWh else None,
                        energy_is_measured=True, warning=None)
        eta = R.get("comp.overall_efficiency")
        return dict(unit="CSU", ideal_work_kWh=w_ideal, energy_kWh=w_ideal / eta,
                    overall_efficiency=eta, energy_is_measured=False,
                    uncertainty_rel=R.entry("comp.overall_efficiency")["uncertainty"],
                    warning="compression energy = ideal work / GUESS efficiency (+-50%); meter the Kaeser")
