"""Regenerate docs/02_uncertainty_register.md from registry.py. Run after any registry edit."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from verlustmappe import registry as R

ORDER = {"BACKLOG": 0, "GUESS": 1, "DERIVED": 2, "DATASHEET": 3, "MEASURED": 4}

def main():
    rows = sorted(((v["status"], k, v) for k, v in R.REGISTRY.items()),
                  key=lambda r: (ORDER[r[0]], -float(r[2]["uncertainty"]) if isinstance(r[2]["uncertainty"], (int, float)) else 0))
    L = ["# Uncertainty register", "",
         "All assumptions in the model, sorted from weakest to strongest. Generated from",
         "`src/verlustmappe/registry.py` by `reporting/make_register.py`; edit the registry, not this file.", "",
         "Status: BACKLOG = placeholder, MUST be replaced. GUESS = assumption bounded only by literature/physics.",
         "DERIVED = computed from other entries. DATASHEET = manufacturer claim. MEASURED = measured by us.", "",
         "| Status | Key | Value | Unit | Rel. unc. | Source | What it drives |", "|---|---|---|---|---|---|---|"]
    for st, k, v in rows:
        L.append(f"| {st} | `{k}` | {v['value']} | {v['unit']} | {v['uncertainty']} | {v['source']} | {v['effect']} |")
    L += ["", "## The five weakest numbers and how to fix each", "",
          "1. `stor.volume_L` (BACKLOG). Read the tank nameplates, sum geometric volumes. Route 2 is meaningless until then.",
          "2. `comp.overall_efficiency` (GUESS +-50%). Energy meter on the Kaeser air compressor during booster runs.",
          "3. `dry.vent_fraction` (GUESS +-50%). Bound with a long charge window: Faraday - tank-pV - known leaks.",
          "4. `stor.gauge_uncertainty_rel` (GUESS). Calibrate the gauge once; plan pressure swings > 100 bar.",
          "5. `el.n_cells` / `fc.n_cells` (GUESS). Ask the manufacturers; Faraday routes scale linearly with them.",
          "", "## Constants by construction (never present as measurements)", "",
          "- EL efficiency via the nameplate route = 62.4% LHV for any data.",
          "- FC efficiency via the nameplate route = 42.9% LHV for any data (a lower bound: nameplate says '<70 g/kWh')."]
    open(os.path.join(ROOT, "docs", "02_uncertainty_register.md"), "w").write("\n".join(L) + "\n")
    print("wrote docs/02_uncertainty_register.md with", len(rows), "entries")

if __name__ == "__main__": main()
