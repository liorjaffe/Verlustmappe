"""Publication-style plots, all testable on synthetic data. Outputs PNG + PDF."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

def plot_loss_map(accounts, fname="loss_map"):
    """accounts: ordered list of dicts with unit + energy_in/out/aux. Waterfall of losses."""
    labels, values = [], []
    total = 0.0
    for a in accounts:
        name = a["unit"]
        if "energy_in_kwh" in a:
            total = a["energy_in_kwh"]
        loss = a.get("loss_kwh")
        if loss is not None:
            labels.append(name); values.append(loss)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(labels, values, color="#c0392b")
    ax.set_ylabel("Energy loss [kWh]")
    ax.set_title(f"Loss map (input {total:.1f} kWh)")
    fig.tight_layout(); fig.savefig(f"{fname}.png", dpi=200); fig.savefig(f"{fname}.pdf")
    plt.close(fig)
    return f"{fname}.png"

def plot_rte_by_mode(rte_by_mode, fname="rte_by_mode"):
    """rte_by_mode: dict mode -> rte fraction."""
    modes = list(rte_by_mode); vals = [100*rte_by_mode[m] for m in modes]
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(modes, vals, color="#2471a3")
    ax.set_ylabel("Round-trip efficiency [%]")
    ax.set_title("RTE by operating mode")
    for x, v in zip(modes, vals):
        ax.text(x, v, f"{v:.1f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout(); fig.savefig(f"{fname}.png", dpi=200); fig.savefig(f"{fname}.pdf")
    plt.close(fig)
    return f"{fname}.png"

def plot_routes(routes, fname="gas_routes"):
    """routes: list of dicts route -> kg. Bar comparison + spread annotation."""
    names = [r["route"] for r in routes]
    g = [r["kg"]*1000 for r in routes]
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(names, g, color="#1e8449")
    ax.set_ylabel("H2 mass [g]")
    spread = (max(g)-min(g))/np.mean(g)*100 if np.mean(g) else 0
    ax.set_title(f"H2 route comparison (spread {spread:.1f}%)")
    fig.tight_layout(); fig.savefig(f"{fname}.png", dpi=200); fig.savefig(f"{fname}.pdf")
    plt.close(fig)
    return f"{fname}.png"

def plot_uncertainty_band(band, fname="rte_uncertainty"):
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.errorbar([0], [100*band["mean"]], yerr=[[100*(band["mean"]-band["lo"])],
                [100*(band["hi"]-band["mean"])]], fmt="o", capsize=8, color="#2471a3")
    ax.set_xticks([]); ax.set_ylabel("RTE [%]")
    ax.set_title(f"Monte-Carlo band, n={band['n']}")
    fig.tight_layout(); fig.savefig(f"{fname}.png", dpi=200); fig.savefig(f"{fname}.pdf")
    plt.close(fig)
    return f"{fname}.png"
