#!/usr/bin/env python3
"""One-command reports over a processed dataset.

Usage:
  python3 src/report_cli.py fc ../data/processed/fc_retro/fc_merged.csv
  python3 src/report_cli.py pv ../data/processed/pv_retro/pv_merged.csv

fc: steady segments ( Kennwerte ), purge events, polarization fit, energy
pv: daily yields, inverter efficiency by load bin, inverter loss
Outputs: CSV tables into results/tables/ and PNGs into results/plots/.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
import numpy as np
import pandas as pd
from verlustmappe.balance.segments import steady_segments
from verlustmappe.balance.events import detect_events, purge_candidates

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
TBL = os.path.join(ROOT, "results", "tables")
PLT = os.path.join(ROOT, "results", "plots")
os.makedirs(TBL, exist_ok=True); os.makedirs(PLT, exist_ok=True)

def fc_report(path):
    from verlustmappe.loaders.grafana import map_fc
    df = map_fc(pd.read_csv(path, index_col=0, parse_dates=True))
    out = []
    segs = steady_segments(df, col="fc_power_W", p_min=1000, min_dur_s=120, extra_cols=("fc1_current_A", "fc1_voltage_V")).to_dict("records")
    pd.DataFrame(segs).to_csv(os.path.join(TBL, "fc_steady_segments.csv"), index=False)
    out.append(f"steady segments: {len(segs)} -> fc_steady_segments.csv")
    ev, st = detect_events(df, [c for c in ["fc_power_W", "fc1_voltage_V", "anode_pressure_mbar"] if c in df.columns])
    ev.to_csv(os.path.join(TBL, "fc_events.csv"), index=False)
    out.append(f"robust events: {len(ev)} -> fc_events.csv")
    purges = purge_candidates(df, "anode_pressure_mbar")
    purges.to_csv(os.path.join(TBL, "fc_purge_events.csv"), index=False)
    out.append(f"purge events: {len(purges)} -> fc_purge_events.csv")
    # polarization fit
    v, i = df.get("fc1_voltage_V"), df.get("fc1_current_A")
    if v is not None and i is not None:
        m = (i > 2).values
        c = np.polyfit(i[m].values, v[m].values, 2)
        with open(os.path.join(TBL, "fc_polarization_fit.csv"), "w") as f:
            f.write("a2,a1,a0,n_points\n%f,%f,%f,%d\n" % (c[0], c[1], c[2], m.sum()))
        out.append("TERMINAL V-I fit (not stack polarisation): V = %.4g*I^2 + %.4g*I + %.2f (%d pts)" % (c[0], c[1], c[2], m.sum()))
    t = df.index.values.astype("datetime64[ns]").astype(np.int64)/1e9
    p = df["fc_power_W"].interpolate(limit_direction="both").values.clip(0, None)
    e = np.trapezoid(p, t)/3.6e6
    with open(os.path.join(TBL, "fc_energy_summary.csv"), "w") as f:
        f.write("energy_kwh,duration_h\n%.3f,%.2f\n" % (e, (t[-1]-t[0])/3600))
    out.append(f"window energy: {e:.2f} kWh -> fc_energy_summary.csv")
    # IV / Kennwerte from steady segments
    from verlustmappe.analysis.polarization import iv_from_segments, key_values
    iv = iv_from_segments(segs, v_col="fc1_voltage_V_mean", i_col="fc1_current_A_mean", p_col="P_mean")
    if not iv.empty:
        iv.to_csv(os.path.join(TBL, "fc_iv_table.csv"), index=False)
        kv = key_values(iv, area_cm2=None)
        pd.DataFrame([kv]).to_csv(os.path.join(TBL, "fc_key_values.csv"), index=False)
        out.append("IV table + Kennwerte -> fc_iv_table.csv, fc_key_values.csv")
    # start/stop cycles with energies
    from verlustmappe.analysis.dynamics import start_stop_cycles, ramp_rates
    cyc = start_stop_cycles(df, rated_w=2500.0)
    cyc.to_csv(os.path.join(TBL, "fc_start_stop_cycles.csv"), index=False)
    out.append(f"start/stop cycles: {len(cyc)} -> fc_start_stop_cycles.csv")
    rr = ramp_rates(df)
    pd.DataFrame([{"channel": k, **v} for k, v in rr.items()]).to_csv(
        os.path.join(TBL, "fc_ramp_rates.csv"), index=False)
    out.append("ramp rates -> fc_ramp_rates.csv")
    # purge voltage recovery
    from verlustmappe.analysis.purge_recovery import recovery_after_purges
    if len(purges):
        rec = recovery_after_purges(df, list(purges["start"]))
        rec.to_csv(os.path.join(TBL, "fc_purge_recovery.csv"), index=False)
        out.append(f"purge voltage recovery: {len(rec)} -> fc_purge_recovery.csv")
    return out

def pv_report(path):
    df = pd.read_csv(path, index_col=0, parse_dates=True)
    cum = df["ac_energy_Wh_cum"].dropna()
    daily = (cum.resample("D").last() - cum.resample("D").first()).dropna().div(1000)
    daily.rename("kWh").to_csv(os.path.join(TBL, "pv_daily_yield.csv"))
    out = [f"daily yield rows: {len(daily)} -> pv_daily_yield.csv",
           f"total: {daily.sum():.1f} kWh over {len(daily)} days"]
    both = df[["dc_power_W", "ac_power_W"]].dropna()
    both = both[both["dc_power_W"] > 500]
    rows = []
    for lo, hi in [(500,2000),(2000,10000),(10000,30000),(30000,70000)]:
        m = both[(both.dc_power_W >= lo) & (both.dc_power_W < hi)]
        if len(m):
            rows.append(dict(bin_W=f"{lo}-{hi}", eta_ac_dc=round(float((m.ac_power_W/m.dc_power_W).mean()), 4),
                             n=len(m), loss_W_mean=round(float((m.dc_power_W-m.ac_power_W).mean()), 1)))
    t = pd.DataFrame(rows); t.to_csv(os.path.join(TBL, "pv_inverter_efficiency.csv"), index=False)
    out.append("inverter eta by load bin -> pv_inverter_efficiency.csv")
    return out

if __name__ == "__main__":
    kind, path = sys.argv[1], sys.argv[2]
    rows = fc_report(path) if kind == "fc" else pv_report(path)
    print("\n".join("PASS  " + r for r in rows))
