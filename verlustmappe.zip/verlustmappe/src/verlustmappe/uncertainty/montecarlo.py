"""Monte-Carlo band for the loss map (GUM Supplement 1, JCGM 101:2008).

Every registry entry with status GUESS/DATASHEET/DERIVED is drawn from a normal
distribution N(value, value*uncertainty); the loss map is recomputed; the
5th/95th percentiles of the outputs are reported. BACKLOG entries are also
perturbed but the result is meaningless until they hold real values.

What the band does NOT contain: measurement noise of the power telemetry
(entered separately via meas.power_rel_unc) and any systematic error in the
formulas themselves. It is a band over ASSUMPTIONS, which is exactly what a
reviewer asks for when there is no hydrogen meter.
"""
import numpy as np
from .. import registry as R
from ..balance.chain import loss_map

def loss_map_band(df_charge, df_discharge, n=500, seed=0, ci=(5, 95), **kw):
    rng = np.random.default_rng(seed)
    keys = [k for k, v in R.REGISTRY.items() if isinstance(v["value"], (int, float))
            and not isinstance(v["value"], bool) and v["uncertainty"] > 0 and v["status"] != "MEASURED"]
    saved = {k: R.REGISTRY[k]["value"] for k in keys}
    rtes, bars = [], []
    try:
        for _ in range(n):
            for k in keys:
                R.REGISTRY[k]["value"] = saved[k] * float(rng.normal(1.0, R.REGISTRY[k]["uncertainty"]))
            out = loss_map(df_charge, df_discharge, **kw)
            if out["rte"]["rte"] is not None:
                rtes.append(out["rte"]["rte"]); bars.append([b["kWh"] for b in out["bars"]])
    finally:
        for k, v in saved.items(): R.REGISTRY[k]["value"] = v
    rtes = np.array(rtes); bars = np.array(bars)
    lo, hi = np.percentile(rtes, ci)
    return dict(rte_mean=float(rtes.mean()), rte_lo=float(lo), rte_hi=float(hi), n=len(rtes),
                bar_names=[b["stage"] for b in loss_map(df_charge, df_discharge, **kw)["bars"]],
                bar_lo=np.percentile(bars, ci[0], axis=0).tolist(),
                bar_hi=np.percentile(bars, ci[1], axis=0).tolist(),
                perturbed_keys=keys)
