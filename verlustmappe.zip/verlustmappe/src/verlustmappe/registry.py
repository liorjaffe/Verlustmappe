"""Device parameter registry: every number the model needs that is NOT a
physical constant. This is the project's "list of assumptions".

Each entry carries:
  value        the number used
  unit         its unit
  source       where it comes from (datasheet page, paper, measurement, or
               the honest word ASSUMPTION)
  status       how much to trust it, one of:
                 DATASHEET  manufacturer claim, not verified by us
                 MEASURED   we measured it with a named instrument
                 DERIVED    computed from other entries
                 GUESS      an assumption; must be bounded by data later
                 BACKLOG    placeholder; MUST be replaced before any paper number
  uncertainty  relative (fraction) unless the unit says otherwise
  effect       what result this number drives (so you know what breaks if
               it is wrong)

Rule: no calculation may hard-code a number that belongs here.
"""

def P(value, unit, source, status, uncertainty, effect):
    return dict(value=value, unit=unit, source=source, status=status,
                uncertainty=uncertainty, effect=effect)

REGISTRY = {
    # ===================== ELECTROLYSER: Enapter AEM EL 2.1 =====================
    "el.production_rate_NLh": P(500, "NL/h", "Enapter EL 2.1 datasheet (ELE21-DTS-COM02)", "DATASHEET", 0.02,
                                "nominal H2 output; cross-check for Faraday route"),
    "el.power_operative_W":   P(2400, "W", "Enapter EL 2.1 datasheet", "DATASHEET", 0.02,
                                "nominal AC input; steady-state expectation"),
    "el.power_standby_W":     P(15, "W", "Enapter EL 2.1 datasheet", "DATASHEET", 0.05,
                                "standby loss bar in the loss map"),
    "el.spec_energy_kWh_per_Nm3": P(4.8, "kWh/Nm3", "Enapter EL 2.1 datasheet, beginning of life", "DATASHEET", 0.03,
                                "FALLBACK H2 estimate when no stack current is logged; "
                                "WARNING: makes EL efficiency a constant 62.4% by construction"),
    "el.output_pressure_barg": P(35, "barg", "Enapter EL 2.1 datasheet", "DATASHEET", 0.0,
                                "compressor inlet pressure"),
    "el.h2_purity":           P(0.999, "mol fraction", "Enapter EL 2.1 datasheet (35 bar)", "DATASHEET", 0.0005,
                                "mass bookkeeping: impurities are not H2"),
    "el.water_consumption_mLh": P(400, "mL/h", "Enapter EL 2.1 datasheet", "DATASHEET", 0.10,
                                "Route 4 (water balance) expectation"),
    "el.n_cells":             P(120, "-", "ASSUMPTION consistent with 2400 W / (120 x 2.0 V) = 10 A; "
                                "CONFIRM from Enapter (stack spec not public)", "GUESS", 0.05,
                                "Faraday route scales linearly with this number"),
    "el.faradaic_efficiency": P(0.98, "-", "ASSUMPTION: literature AEM/PEM current efficiency 96-99% "
                                "(Yodwong et al., Energies 2020, 13, 4792)", "GUESS", 0.02,
                                "Faraday route H2 mass; blind to shunt current and crossover"),
    "el.startup_duration_s":  P(990, "s", "UFSC PV-electrolysis study: EL2.1 ramp to nominal after ~990 s", "DERIVED", 0.15,
                                "operating-mode partition: startup window length"),

    # ===================== DRYER: Enapter DRY 2.1 (35 bar) =====================
    "dry.power_operative_W":  P(200, "W", "DRY 2.1 datasheet", "DATASHEET", 0.02,
                                "dryer electrical loss bar; NOTE datasheet also states 0.045 kWh/Nm3 "
                                "at 2.5 Nm3/h = 112 W average, so 200 W is an UPPER envelope"),
    "dry.power_standby_W":    P(10, "W", "DRY 2.1 datasheet", "DATASHEET", 0.05, "standby loss"),
    "dry.rate_Nm3h":          P(2.5, "Nm3/h", "DRY 2.1 datasheet (35 bar version)", "DATASHEET", 0.0, "capacity check"),
    "dry.spec_energy_kWh_Nm3": P(0.045, "kWh/Nm3", "DRY 2.1 datasheet", "DATASHEET", 0.03,
                                "alternative dryer energy estimate: flow-proportional"),
    "dry.max_h2_content_NL":  P(47, "NL", "DRY 2.1 datasheet (safety: max H2 in device)", "DATASHEET", 0.0,
                                "upper bound of H2 lost per regeneration blow-down"),
    "dry.vent_fraction":      P(0.04, "fraction of throughput", "ASSUMPTION: TSA/PSA regeneration vents the cartridge "
                                "hold-up; unmeasured", "GUESS", 0.5,
                                "gas loss bar in the loss map; bound it via long-run tank-pV vs Faraday residual"),

    # ============ COMPRESSOR: Maximator DLE 30-2 air-driven gas booster ============
    "comp.pressure_ratio":    P(60, "-", "Maximator DLE 30-2 TDS", "DATASHEET", 0.0, "stall pressure check"),
    "comp.stroke_volume_cm3": P(120, "cm3/double stroke", "Maximator DLE 30-2 TDS", "DATASHEET", 0.0, "flow capacity check"),
    "comp.max_cycles_per_min": P(100, "1/min", "Maximator DLE 30-2 TDS", "DATASHEET", 0.0, "flow capacity check"),
    "comp.min_suction_bar":   P(20, "bar", "Maximator DLE 30-2 TDS", "DATASHEET", 0.0, "storage lower pressure limit"),
    "comp.overall_efficiency": P(0.10, "-", "ASSUMPTION: ideal isothermal H2 work / electrical energy of the "
                                "compressed-air supply (Kaeser). Air-driven boosters are notoriously "
                                "inefficient; 5-15% typical.", "GUESS", 0.5,
                                "compression loss bar; MUST be replaced by Kaeser energy measurement"),

    # ===================== STORAGE =====================
    "stor.volume_L":          P(100, "L", "PLACEHOLDER - enter the real geometric tank volume", "BACKLOG", 0.01,
                                "Route 2 (tank pV) mass scales linearly with this"),
    "stor.p_max_barg":        P(300, "barg", "UFSC lab description (tanks up to 300 bar)", "DATASHEET", 0.0, "range check"),
    "stor.p_min_barg":        P(20, "barg", "= booster minimum suction pressure", "DERIVED", 0.0, "depth of discharge"),
    "stor.gauge_uncertainty_rel": P(0.02, "-", "ASSUMPTION: analog gauge, read manually, class ~1.6 + parallax", "GUESS", 0.5,
                                "Route 2 uncertainty; calibrate the gauge to shrink this"),

    # ============ FUEL CELL: Intelligent Energy IE-LIFT 802 (x2) ============
    "fc.rated_power_W":       P(2500, "W at 48 V", "IE-LIFT 802 nameplate", "DATASHEET", 0.0, "load-bin normalisation"),
    "fc.h2_consumption_g_per_kWh": P(70, "g/kWh", "IE-LIFT 802 nameplate: '<70 g per kWh' at 25 C, beginning of life",
                                "DATASHEET", 0.05,
                                "nameplate H2 route. NOTE: it is an UPPER BOUND on consumption, hence a "
                                "LOWER BOUND on efficiency (42.9% LHV), and makes FC efficiency a constant "
                                "by construction. Load dependence needs the stack-current route."),
    "fc.n_cells":             P(120, "-", "ASSUMPTION (IE-LIFT stack spec not public); CONFIRM", "GUESS", 0.05,
                                "reverse-Faraday route"),
    "fc.faradaic_efficiency": P(1.00, "-", "ASSUMPTION: all stack current from H2 oxidation (no crossover)", "GUESS", 0.02,
                                "reverse-Faraday route"),
    "fc.control_input_W_max": P(150, "W", "IE-LIFT 802 nameplate 'Rated Input 150 W max'", "DATASHEET", 0.05,
                                "auxiliary/control energy on discharge; nameplate MAX, so an upper envelope"),
    "fc.poc_max_duration_s":  P(12, "s", "FCM802_Test research plan / user manual", "DERIVED", 0.0, "POC event window"),
    "fc.has_internal_dcdc":   P(True, "bool", "IE-LIFT 802 telemetry exposes 'DC/DC Voltage Set Point' and "
                                "'DC/DC Current Limit'; output 20-56 V follows the bus", "DATASHEET", 0.0,
                                "Terminal V/I is NOT stack V/I. Terminal V-I curve is a converter "
                                "characteristic, not a polarisation curve."),

    # ===================== BATTERY (no sensor) =====================
    "bat.capacity_Ah":        P(100, "Ah", "PLACEHOLDER - enter the real battery capacity", "BACKLOG", 0.05,
                                "SoC bookkeeping route for the battery branch"),
    "bat.nominal_V":          P(48, "V", "system DC bus", "DATASHEET", 0.01, "SoC energy conversion"),

    # ===================== PV / INVERTER =====================
    "pv.p_dc_stc_W":          P(0, "W", "PLACEHOLDER - array STC power from module datasheets", "BACKLOG", 0.0,
                                "capture-ratio bar (optional)"),

    # ===================== MEASUREMENT CHAIN =====================
    "meas.power_rel_unc":     P(0.02, "-", "ASSUMPTION: device-reported power (Enapter/SMA telemetry), "
                                "no independent power analyser yet", "GUESS", 0.5,
                                "floor of every efficiency's uncertainty"),
}

def get(key):
    return REGISTRY[key]["value"]

def entry(key):
    return REGISTRY[key]

def by_status(status):
    return {k: v for k, v in REGISTRY.items() if v["status"] == status}
