"""Verlustmappe: energy loss map of a PV -> H2 -> fuel cell island system.

Reading order for a newcomer: README.md -> docs/01_methods_handbook.md ->
constants.py -> registry.py -> conversions.py -> hydrogen/ -> devices/ ->
balance/ -> analysis/ -> uncertainty/.
"""
