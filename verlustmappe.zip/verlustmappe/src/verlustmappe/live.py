"""Live layer: rolling-window pipeline between telemetry stream and plotter.
No hardware dependency: feeds on any generator of DataFrames (mock included)."""
import json
import numpy as np
import pandas as pd
from .devices import ElectrolyzerUnit
from .devices import FuelCellSystem
from .balance.modes import partition_modes

class LivePipeline:
    """Call .push(df_window) periodically; get back a plain dict for the plotter."""

    def __init__(self, dt_s=1.0, window_s=600):
        self.dt_s = dt_s
        self.window_s = window_s
        self.el = ElectrolyzerUnit()
        self.fcs = FuelCellSystem()

    def push(self, df):
        out = {"ts": str(df.index[-1]) if len(df) else None,
               "n_points": int(len(df))}
        poc = _detect_poc(df, "fc_power_W")
        power_col = "power_W" if "power_W" in df.columns else ("fc_power_W" if "fc_power_W" in df.columns else None)
        if power_col is not None:
            dfm = partition_modes(df, power_col=power_col, events=poc)
            counts = dfm["mode"].value_counts().to_dict()
            out["modes"] = counts
            if "el_current_A" in df.columns or "el_stack_current_A" in df.columns:
                acc = self.el.account(df)
                out["el"] = {"power_kW": df["power_W"].mean()/1000,
                             "h2_NLh": acc["h2"]["NL"] / (len(df)*self.dt_s/3600.0),
                             "eta_LHV": acc["efficiency_LHV"],
                             "route": acc["h2"]["route"]}
            if "fc_power_W" in df.columns:
                dfm = partition_modes(df, power_col="fc_power_W", events=poc)
                acc = self.fcs.account(dfm)
                out["fc"] = {"power_kW": df["fc_power_W"].mean()/1000,
                             "eta_LHV": acc["efficiency_LHV"],
                             "h2_route": acc["h2"]["route"], "h2_g": acc["h2"]["kg"]*1000}
        return out

    def push_json(self, df):
        return json.dumps(self.push(df), default=str)

def _detect_poc(df, col="fc_power_W", thresh=0.5):
    """POC = sustained drop below thresh*median for >=3 consecutive samples."""
    if col not in df.columns or len(df) < 5:
        return []
    v = df[col].values
    med = np.median(v)
    low = v < thresh * med
    events, start = [], None
    for i, flag in enumerate(low):
        if flag and start is None: start = i
        if not flag and start is not None:
            if i - start >= 3: events.append((start, i))
            start = None
    if start is not None and len(v) - start >= 3: events.append((start, len(v)))
    return events

def mock_stream(duration_s=3600, dt_s=1.0, poc_at=(1200, 1212), seed=0):
    """Synthetic 1-s telemetry stream: steady FC load with a POC dip + battery assist."""
    rng = np.random.default_rng(seed)
    n = int(duration_s/dt_s)
    t = pd.timedelta_range(0, periods=n, freq=f"{int(dt_s)}s")
    p = np.full(n, 2400.0) * (1 + 0.02*rng.standard_normal(n))
    i1 = np.full(n, 19.39) * (1 + 0.02*rng.standard_normal(n))
    i2 = np.full(n, 19.39) * (1 + 0.02*rng.standard_normal(n))

    p[poc_at[0]:poc_at[1]] *= 0.2          # FC output collapses during POC
    df = pd.DataFrame({"fc_power_W": p, "fc1_stack_current_A": i1,
                       "fc2_stack_current_A": i2,
                       "load_current_A": p/48},
                      index=t)
    return df

def iter_windows(df, window_s, dt_s):
    n = int(window_s/dt_s)
    for start in range(0, len(df) - n, n):
        yield df.iloc[start:start+n]
