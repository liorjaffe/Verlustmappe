"""Efficiency vs temperature and NL->g conversion.
WARNING: uses the device-reported H2 flow (Route 3), which is correlated with
the electrical data; treat the result as a trend, not an independent measurement."""
import numpy as np
import pandas as pd

from ..constants import RHO_H2_KG_PER_NL, LHV_H2_WH_PER_NL, HHV_H2_WH_PER_NL
H2_G_PER_NL = RHO_H2_KG_PER_NL * 1000.0

def nl_to_g(nl): return nl * H2_G_PER_NL

def efficiency_vs_temperature(df, power_col, h2_flow_col, temp_col, basis="LHV"):
    """eta(t) using telemetry H2 flow (Route 3, correlated - label accordingly)."""
    kwh_per_nl = (LHV_H2_WH_PER_NL if basis == "LHV" else HHV_H2_WH_PER_NL) / 1000.0
    d = df[[power_col, h2_flow_col, temp_col]].dropna()
    d = d[d[h2_flow_col] > 1]
    chem_kwh = d[h2_flow_col] * kwh_per_nl
    eta = d[power_col] / 1000.0 / chem_kwh
    out = pd.DataFrame({"eta": eta, "T": d[temp_col]})
    bins = pd.cut(out["T"], bins=6)
    return out.groupby(bins, observed=True).agg(T_mean=("T", "mean"), eta_mean=("eta", "mean"),
                                                eta_std=("eta", "std"), n=("eta", "size")).reset_index()
