"""Characterisation methods that turn steady segments and events into the
numbers a paper reports: characteristic curves, efficiency vs load/temperature,
dynamic response, start/stop energies, degradation, dataset comparison."""
