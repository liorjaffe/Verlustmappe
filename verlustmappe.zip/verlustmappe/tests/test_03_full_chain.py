"""Whole loss map on a synthetic cycle with physically consistent truth."""
import _path
import numpy as np, pandas as pd
from verlustmappe import registry as R
from verlustmappe.balance.chain import loss_map
from verlustmappe.uncertainty import loss_map_band

def main():
    R.REGISTRY["stor.volume_L"]["value"] = 1000.0
    n = 361
    idx = pd.date_range("2026-01-01", periods=n, freq="60s")
    dfc = pd.DataFrame({"power_W": np.full(n, 2400.0), "el_stack_current_A": np.full(n, 10.0)}, index=idx)
    n2 = 121
    idx2 = pd.date_range("2026-01-02", periods=n2, freq="60s")
    dfd = pd.DataFrame({"fc_power_W": np.full(n2, 2500.0),
                        "fc1_stack_current_A": np.full(n2, 19.39), "fc2_stack_current_A": np.full(n2, 19.39)}, index=idx2)
    # tank end pressure consistent with produced H2 minus vent (bisection on the same physics)
    from verlustmappe.hydrogen import h2_from_tank_pressure
    el0 = loss_map(dfc, dfd, eta_inverter=0.96)["devices"]["EL"]
    target_kg = el0["h2"]["kg"] * (1 - R.get("dry.vent_fraction"))
    lo, hi = 50.0, 300.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        lo, hi = (mid, hi) if h2_from_tank_pressure(50.0, mid)["kg"] < target_kg else (lo, mid)
    p_end = 0.5 * (lo + hi)
    out = loss_map(dfc, dfd, tank_p_start_barg=50.0, tank_p_end_barg=p_end, eta_inverter=0.96)
    assert out["h2_closure"]["max_spread_independent"] < 1e-4, out["h2_closure"]
    el, fc = out["devices"]["EL"], out["devices"]["FC"]
    assert abs(el["energy_in_kWh"] - 14.4) < 1e-6
    assert el["efficiency_is_measured"] and fc["efficiency_is_measured"]
    assert 0.55 < el["efficiency_LHV"] < 0.70, el["efficiency_LHV"]
    assert 0.35 < fc["efficiency_LHV"] < 0.50, fc["efficiency_LHV"]
    rte = out["rte"]["rte"]
    assert 0.20 < rte < 0.35, rte
    assert out["h2_closure"]["n_independent"] == 2
    band = loss_map_band(dfc, dfd, n=150, tank_p_start_barg=50.0, tank_p_end_barg=p_end, eta_inverter=0.96)
    assert band["rte_lo"] <= band["rte_mean"] <= band["rte_hi"]
    print("PASS 03 full chain: EL eta %.1f%%, FC eta %.1f%%, RTE %.1f%% [MC %.1f-%.1f], H2 spread %.1f%%"
          % (el["efficiency_LHV"]*100, fc["efficiency_LHV"]*100, rte*100, band["rte_lo"]*100, band["rte_hi"]*100,
             out["h2_closure"]["max_spread_independent"]*100))
    for b in out["bars"]:
        print("      %-18s %7.3f kWh  [%s]" % (b["stage"], b["kWh"], b["status"]))

if __name__ == "__main__": main()
