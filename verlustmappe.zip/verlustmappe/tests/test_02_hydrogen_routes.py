"""Hydrogen routes on a constructed truth: they must agree when fed consistent data."""
import _path
import numpy as np
from verlustmappe import registry as R
from verlustmappe.hydrogen import (h2_from_stack_current, h2_from_tank_pressure, h2_from_telemetry,
                                   h2_from_water, h2_from_energy_nameplate, compare_routes)
from verlustmappe.hydrogen.realgas import z_h2
from verlustmappe.devices import Tank

def main():
    # Z table checkpoints (NIST/Leachman EOS)
    assert abs(z_h2(350.0, 15.0) - 1.234) < 0.01
    assert abs(z_h2(200.0, 20.0) - 1.132) < 0.005
    assert abs(z_h2(1.013, 20.0) - 1.0) < 0.002
    # density check: 200 bar 20 C -> ~14.6 kg/m3
    t = Tank(); R.REGISTRY["stor.volume_L"]["value"] = 1000.0
    rho = t.stored(200 - 1.01325)["kg"]
    assert 14.4 < rho < 14.8, rho
    # Route 1: 10 A x 6 h x 120 cells x 0.98 -> mol
    I = np.full(360, 10.0); dt = np.full(360, 60.0)
    r1 = h2_from_stack_current([I], dt, 120, 0.98)
    expected = 0.98 * 120 * 10 * 6 * 3600 / (2 * 96485.332)
    assert abs(r1["mol"] - expected) < 1e-9
    # Route 2: construct the pressure rise that stores exactly r1 mass in a 1000 L tank
    R.REGISTRY["stor.volume_L"]["value"] = 1000.0
    p1 = 50.0
    # find p2 by bisection using the same physics the tank uses
    lo, hi = p1, 300.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        m = h2_from_tank_pressure(p1, mid)["kg"]
        lo, hi = (mid, hi) if m < r1["kg"] else (lo, mid)
    r2 = h2_from_tank_pressure(p1, 0.5 * (lo + hi))
    assert abs(r2["kg"] - r1["kg"]) / r1["kg"] < 1e-6
    # Route 4: water 9x mass
    r4 = h2_from_water(r1["kg"] * 18.015 / 2.016)
    assert abs(r4["kg"] - r1["kg"]) / r1["kg"] < 1e-9
    # closure over independent routes -> spread ~0
    c = compare_routes([r1, r2, r4])
    assert c["n_independent"] == 3 and c["max_spread_independent"] < 1e-5
    # nameplate route is a constant-efficiency bound
    rn = h2_from_energy_nameplate(14.4, "el")
    assert abs(rn["kWh_LHV"] / 14.4 - 0.624) < 0.01
    print("PASS 02 hydrogen routes: Z table, Faraday, tank-pV, water, closure, nameplate bound")

if __name__ == "__main__": main()
